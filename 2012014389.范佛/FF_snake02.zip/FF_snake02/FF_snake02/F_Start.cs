﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FF_snake02
{
    class F_Start
    {
        static void NotMain()
        {
            Application.Run(new Form1());
        }
    }
}
